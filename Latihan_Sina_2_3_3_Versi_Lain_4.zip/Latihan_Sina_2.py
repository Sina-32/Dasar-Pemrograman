'''
Nama : Sina
Nim : 2400606
Kelas : 1B
'''
Alas = int(input("Masukan Alas: "))
Tinggi = int(input("Mauksan Tinggi: "))
Luas = Alas * Tinggi/2

print(f"Luas Segitiga: {Luas}") 
