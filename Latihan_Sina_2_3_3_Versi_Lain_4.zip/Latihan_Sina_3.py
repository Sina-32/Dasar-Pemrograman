'''
Nama : Sina
Nim : 2400606
Kelas : 1B
'''
nama = input("Nama : ")
tahun_lahir = int(input("Tahun Lahir : "))
tahun_ini = 2024
umur = tahun_ini - tahun_lahir
print(f"Selamat Datang {nama} umur kamu {umur}")