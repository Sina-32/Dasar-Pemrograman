'''
Nama : Sina
Nim : 2400606
Kelas : 1B
'''
a = int(input("Angka :"))
b = int(input("Angka :"))
c = int(input("Angka :"))
hasil = a + b + c
print(f"Hasil penjumlahan {a} + {b} + {c} adalah {hasil}")