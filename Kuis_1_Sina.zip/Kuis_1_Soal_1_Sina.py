"""
Nama: Sina Pijar Sahmura 
Nim: 2400606
Kelas: 1B
"""
Panjang=8*100
Tinggi=400
Lebar=1000
Luas_Permukaan_Dinding=2*(Panjang*Tinggi)+2*(Lebar*Tinggi)
Biaya_Pembuatan=int(Luas_Permukaan_Dinding*450.000)
print(f"Biaya pembuatannya adalah {Biaya_Pembuatan}")
#