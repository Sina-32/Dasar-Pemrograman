"""
Nama: Sina Pijar Sahmura 
Nim: 2400606
Kelas: 1B
"""
Menit = int(input("Menit : "))
Detik = Menit*60
print(f"Detik : {Detik} ")
#
