"""
Nama: Sina Pijar Sahmura 
Nim: 2400606
Kelas: 1B
"""
Nilai_Input= int(input("Nilai : "))
Nilai_Siwa= [87.7, 56.5, 93.2, 67.8, 65.0, 38.5, 42.8, 74.5, 89.0, 93.2]
Nilai = Nilai_Siwa[Nilai_Input - 1]
print(f"Nilai Siswa {Nilai}")
#