"""
Nama: Sina Pijar Sahmura 
Nim: 2400606
Kelas: 1B
"""
Keliling_Persegi_Panjang= 2*(100*100)+2*4800*10
print(f"Jarak yang di tempuh {Keliling_Persegi_Panjang}")
#