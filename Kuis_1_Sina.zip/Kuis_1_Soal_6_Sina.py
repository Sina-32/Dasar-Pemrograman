"""
Nama: Sina Pijar Sahmura 
Nim: 2400606
Kelas: 1B
"""
Barang_Juli=["T-Shirt, Blouse, Kemeja, Celana Panjang, Rok, Baju Renang, Tas, Topi, Sepatu, Sendal"]
print(Barang_Juli)
Barang_Juli[7]="Dompet"
Barang_Juli.append("Jepitan Rambut")
Barang_Juli.append("Kerudung")
print(Barang_Juli)