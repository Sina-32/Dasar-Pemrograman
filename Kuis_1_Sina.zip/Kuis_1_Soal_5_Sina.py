"""
Nama: Sina Pijar Sahmura 
Nim: 2400606
Kelas: 1B
"""
Mobil={
    "Merk" : "Honda",
    "Tipe" : "HRV",
    "Tahun" : "2018",
    "Warna" : "Hitam",
    "No. Polisi" : "D 1234 ABC",
    "Bensin" : "Pertalite",
    "Tranmisi" : "Manual"
}
print(Mobil)
Mobil.update({"Tipe":["Civic Turbo"]})
Mobil.update({"Tahun":["2023"]})
Mobil.update({"Warna":["Merah"]})
Mobil.update({"No. Polisi":["D 0 KI"]})
Mobil.update({"Bensin":["Pertamax"]})
Mobil.update({"Tranmisi":["Automatic"]})
print(Mobil)
