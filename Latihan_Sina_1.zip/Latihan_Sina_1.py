'''
Nama : Sina
Nim : 2400606
Kelas : 1B
'''
nama = input("Nama : ")
umur = input("Umur : ")
print(f"Selamat Datang {nama} umur kamu {umur}")
