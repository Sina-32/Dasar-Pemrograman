'''
Nama : Sina
Nim : 2400606
Kelas : 1B
'''
Jakarta = (-6.2088, 106.8456)
Bandung = (-6.9175, 107.6192)
Surabaya = (-7.2575, 112.7521)
print(f"Koordinat Kota Bandung : {Bandung}")
Kota = (Jakarta, Bandung, Surabaya)
print(f"Jumlah Kota Yang Disimpan : {len(Kota)}")