'''
Nama : Sina
Nim : 2400606
Kelas : 1B
'''
number=[10,20,20,30,40,50,50,60]
setnumber=set(number)
print(sorted(setnumber))