'''
Nama : Sina Pijar Sahmura
Nim : 2400606
Kelas : 1B
'''
Barang=int(input("Barang : "))
if(Barang<100):
    print(Barang*5000) #Harga per barang Rp. 5.000
elif(Barang>150):
    print(Barang*2500) #Harga per barang adalah Rp. 2.500
elif(Barang>=100):
    print(Barang*4000) #Harga per barang Rp. 4000