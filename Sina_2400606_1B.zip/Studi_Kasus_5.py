'''
Nama : Sina Pijar Sahmura
Nim : 2400606
Kelas : 1B
'''
Input_bilangan=int(input("Input Bilangan"))