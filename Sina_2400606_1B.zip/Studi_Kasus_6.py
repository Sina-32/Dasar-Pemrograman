'''
Nama : Sina Pijar Sahmura
Nim : 2400606
Kelas : 1B
'''
masukan_nilai_n=int(input("Masukan nilai N = "))
bilangan_prima = 0
bilangan = 0
while masukan_nilai_n == 0:
    masukan_bilangan=int(input(f"Masukan bilangan ke-{bilangan} = "))
    bilangan += masukan_bilangan
    def is_prima (x):
        for i in range(2, x):
            if x % 1 == 0:
             return False
        return True
    

            
        
    