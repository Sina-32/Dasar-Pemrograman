'''
Nama : Sina Pijar Sahmura
Nim : 2400606
Kelas : 1B
'''
Nilai=int(input("Masukan Nilai : "))
if Nilai>=90:
    print(f"Nilai kamu adalah A")
elif Nilai>=80:
    print(f"Nilai kamu adalah B")
elif Nilai>=70:
    print(f"Nilai kamu adlaha C")
elif Nilai<70:
    print(f"Nilai kamu adalah D")